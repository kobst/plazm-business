const awsmobile = {
    "aws_project_region": "us-east-1",
    "aws_cognito_identity_pool_id": "us-east-1:3189e103-8335-4b48-bb26-71e14898acc4",
    "aws_cognito_region": "us-east-1",
    "aws_user_pools_id": "us-east-1_W5dpJ0PhM",
    "aws_user_pools_web_client_id": "7v7acardjlsrksegaim52bbqv4",
    "oauth": {}
};


export default awsmobile;